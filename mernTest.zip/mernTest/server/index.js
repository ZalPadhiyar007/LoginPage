const express = require('express')
const mongoose = require('mongoose')
const cors = require('cors')

const app = express()
app.use(cors())
app.use(express.json())

mongoose.connect('mongodb+srv://zalak:3mhrBHaZ9HaP7hKA@login.vkruxmx.mongodb.net/?authSource=Login&authMechanism=SCRAM-SHA-1')

const UserSchema = new mongoose.Schema({
    email: String,
    password: String
})

const UserModel = mongoose.model("users", UserSchema)

app.post("/Login", (req, res) => {
    const {email, password} = req.body;
    UserModel.findOne({email: email})
    .then(user => {
        if(user) {
            if(user.password === password) {
                res.json("Login Successful!")
            } else {
                res.json("The password is invalid!")
            }
        } else {
            res.json("Couldn't locate account")
        }
    })
})

app.listen(3001, () => {
    console.log("Server is Running");
})